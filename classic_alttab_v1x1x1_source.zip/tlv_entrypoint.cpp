#include "tlv_entrypoint.h"
#include <assert.h>
#include <memory>

// Iterating over all desktop windows in C++, by z-order
// https://gist.github.com/blewert/b6e7b11c565cf82e7d700c609f22d023

const char* szAppName = "Classic AltTab Helper";

int main( int argc, const char*const* argv )
{
	printf("ATZ: Starting... [OWQYjPB]\n");
	AtzAppDTO sAppDTO;
	for( int ii2=1; ii2 < argc; ii2++ ){
		std::string arg0 = argv[ii2];
		std::string arg1 = ( ii2+1 < argc ? argv[ii2+1] : "");
		int nArgAsInt = atoi( arg1.empty() || !isdigit(arg1[0]) ? "1" : arg1.c_str() );
		if( arg0 == "-bStartVisible" ){
			sAppDTO.bStartVisible = !!nArgAsInt;
		}else if( arg0 == "-bTopmost" ){
			sAppDTO.bTopmost = !!nArgAsInt;
		}else if( arg0 == "-bTrayIcon" ){
			sAppDTO.bTrayIcon = !!nArgAsInt;
		}else if( arg0 == "-color_spec" ){
			// five colors, comma separated list, as RGB values.
			std::vector<std::string> parts2;
			hxdw_StrExplode( arg1.c_str(), parts2, {";",}, -1, "\x20\t", "");
			assert( !parts2.empty() && "Five RGB colors expected. Semicolon separated [9MH70GH]" );
			uint32_t* arr2[5] = { &sAppDTO.uClrWindow, &sAppDTO.uClrTextNormal, &sAppDTO.uClrTextSelected, &sAppDTO.uClrBgNormal, &sAppDTO.uClrBgSelected,};
			if( parts2.size() < sizeof(arr2)/sizeof(arr2[0]) ){
				parts2.resize( 5, "");
			}
			for( int ii2=0; ii2 < sizeof(arr2)/sizeof(arr2[0]); ii2++ ){
				if( !parts2[ii2].empty() ){
					*arr2[ii2] = hxdw_ConvColorStrFmtToRGBFmt( parts2[ii2].c_str(),
							"rgb-", "0x00BBGGRR");
				}
			}
		}
	}
	AtzMainWindow ti2( 0, 0, sAppDTO );
	ti2.run2();
	printf("ATZ: Exiting...\n" );
	return 0;
}
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
		LPSTR lpCmdLine, int nCmdShow )
{
	std::vector<std::string> argv2; std::vector<const char*> argv3;
	argv3 = hxdw_GetCommandLine3( &argv2 );
	int rslt = main( (int)argv3.size(), &argv3[0] );
	return rslt;
}

AtzMainWindow::AtzMainWindow( int, int, const AtzAppDTO& sAppDTO_ )
	: mAppDTO(sAppDTO_)
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
}
AtzMainWindow::~AtzMainWindow()
{
	if( mIsInTray ){
		toggleWindowVisibility( 1L );
	}
	if( mNid.hWnd ){
		Shell_NotifyIcon( NIM_DELETE, &mNid );
		memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	}
	{
		DeleteObject( mHBrWindow );
		DeleteObject( mHBrBgNormal );
		DeleteObject( mHBrBgSelected );
		mHBrWindow = mHBrBgNormal = mHBrBgSelected = 0;
	}
}
void AtzMainWindow::toggleWindowVisibility( int bShow2 )
{
	assert( mHwnd );
	if( bShow2 == -1 ){
		bShow2 = !IsWindowVisible(mHwnd);
	}
	assert( bShow2 >= 0 && bShow2 <= 1 );
	if( !bShow2 ){
		ShowWindow(mHwnd, SW_HIDE);//SW_MINIMIZE
		mIsInTray = 1L;
	}else{
		ShowWindow(mHwnd, SW_SHOW);
		ShowWindow(mHwnd, SW_RESTORE);
		SetForegroundWindow(mHwnd);
		mIsInTray = 0L;
	}
}
LRESULT CALLBACK
WndProc2( HWND hWnd, UINT msg2, WPARAM wParam, LPARAM lParam )
{
	AtzMainWindow* this2 = (AtzMainWindow*)GetWindowLongPtr( hWnd, GWLP_USERDATA );
	if(this2){
		return this2->WndProc3( hWnd, msg2, wParam, lParam );
	}
	return DefWindowProc( hWnd, msg2, wParam, lParam );
}
// System windows that tabbing should omit, class+exec+title,
// Windows 7 specific:
//     "Shell_TrayWnd", "explorer.exe", "",
//     "Progman",       "explorer.exe", "Program Manager",
std::vector<std::pair<std::string,std::string>>
AtzMainWindow::aSWNeedles = {
		{"Shell_TrayWnd\0;;;;;;;;;;;;;;;;;;;;;;", "explorer.exe\0;;;;;;;;;;;;;;;;;;;;;;;;;;;;",},
		{"Progman\0;;;;;;;;;;;;;;;;;;;;;;;;;;;;", "explorer.exe\0;;;;;;;;;;;;;;;;;;;;;;;;;;;;",},
		{"placeholder_1_class_CbqsNP\0;;;;;;;;;", "placeholder_1_exe_dvZSJg\0;;;;;;;;;;;;;;;;",},
		{"placeholder_2_class_WAxYqi\0;;;;;;;;;", "placeholder_2_exe_GH6EYN\0;;;;;;;;;;;;;;;;",},
};

void AtzMainWindow::onOwnModkeyUp()
{
	//mTabbingWnd,mOldTopWindow
	if( mTabbingWnd && mTabbingWnd != mHwnd ){
		//std::string sr2 = hxdw_GetWindowText( mTabbingWnd );
		//printf("ATZ: Resoring mTabbingWnd... [%s] [Eb7K27X]\n", sr2.c_str() );

		//ShowWindow( mTabbingWnd, SW_SHOW );
		ShowWindow( mTabbingWnd, SW_RESTORE );
		SetForegroundWindow( mTabbingWnd );
		mTabbingWnd = 0;
		toggleWindowVisibility( 0L );
	}
}
LRESULT AtzMainWindow::WndProc3( HWND hWnd, UINT msg2, WPARAM wParam, LPARAM lParam )
{
	if( msg2 == mWMTrayAnyMessageId ){
		if( AtzAny<int>( lParam, {WM_LBUTTONDOWN,WM_LBUTTONDBLCLK,} ) ){
			printf("ATZ: tray icon click.\n");
			toggleWindowVisibility( -1 );
		}
	}else if( msg2 == AtzMainWindow::mWMDestroyLv2Id ){
		DestroyWindow(hWnd);
	}
	switch(msg2){
	case WM_COMMAND:{
			const int wmId = LOWORD(wParam);
			switch( wmId ){
			default:
				return DefWindowProc( hWnd, msg2, wParam, lParam );
			}
		}
		break;
	case WM_DESTROY:
		printf("ATZ: Processing WM_DESTROY\n");
		PostQuitMessage(0);
		return 1L;
	case WM_KEYDOWN:{
			int nVirtKey = (int) wParam;    // virtual-key code
			if( nVirtKey == 'Q' || nVirtKey == VK_ESCAPE ){
				//if( GetAsyncKeyState(VK_CONTROL) & 0x8000 )
				int ans2 = MessageBox( hWnd, "Really quit?", szAppName, MB_OKCANCEL|MB_ICONQUESTION );
				if( ans2 == IDOK ){
					DestroyWindow(hWnd);
				}
			}
		}
		break;
	case WM_HOTKEY: {
			const int idHotKey = (int) wParam;
			//printf("WM_HOTKEY_, id:%d [YzfyFF2]\n", idHotKey );
			bool bFromBackground2 = 0L;
			const HWND hFgWindow = GetForegroundWindow();
			if( mHwnd != hFgWindow ){
				mOldTopWindow = hFgWindow;
				ShowWindow( mHwnd, SW_SHOW );
				ShowWindow( mHwnd, SW_RESTORE );
				SetForegroundWindow( mHwnd );
				bFromBackground2 = 1L;
			}
			onScrollHotkeyAction( idHotKey, bFromBackground2 );
		}
		break;
	case WM_KEYUP:{
			const int nVirtKey = (int) wParam;    // virtual-key code
			if(0){
			}else if( nVirtKey == VK_LWIN ){
				//printf("VK_LWIN up.\n");
				onOwnModkeyUp();//WM_HOTKEY
			}
		}
		break;
/*	case WM_PAINT:{
			static int cnt2 = 0;
			printf("WM_PAINT, %d\n", cnt2++ );
			PAINTSTRUCT pst2;
			HDC hdc3 = BeginPaint( hWnd, &pst2 );
			EndPaint( hWnd, &pst2 );
			return 0;
		}
		break;//*/
	default:
		return DefWindowProc( hWnd, msg2, wParam, lParam );
	}
	return 0;
}
ATOM AtzMainWindow::registerHlprWndClass( HINSTANCE hInstance )
{
	WNDCLASSEX wcex;
	memset( &wcex, 0, sizeof(wcex) );
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc2; //(WNDPROC)
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
//	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
//	wcex.hbrBackground = (HBRUSH) CreateSolidBrush( RGB(255,0,0) );
	wcex.hbrBackground = (HBRUSH)0;
	wcex.lpszMenuName = "ATZ:Helper_Class_SxCDPiD";
	wcex.lpszClassName = "ATZ:Helper_Class_SxCDPiD";
	wcex.hIcon = LoadIcon( nullptr, IDI_ASTERISK );
	return RegisterClassEx(&wcex);
}
void AtzMainWindow::initializeTrayIcon()
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	mNid.cbSize = sizeof(NOTIFYICONDATA);
	mNid.hWnd   = mHwnd;
	mNid.uID    = 1001;// uId ? ++uId : uId = 1;
	mNid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	mNid.uCallbackMessage = mWMTrayAnyMessageId;   //WM_USER+0x210
	mNid.hIcon  = hxdw_GetWindowIcon( mHwnd );
	assert(mNid.hIcon);
	//
	snprintf( mNid.szTip, sizeof(mNid.szTip), "%s", hxdw_GetWindowText( mHwnd ).c_str() );
	Shell_NotifyIcon( NIM_ADD, &mNid );
}
bool AtzMainWindow::initInstance( HINSTANCE hInstance, int nCmdShow )
{
	{
		assert( !mHBrWindow && !mHBrBgNormal && !mHBrBgSelected );
		mHBrWindow = CreateSolidBrush( mAppDTO.uClrWindow );
		mHBrBgNormal = CreateSolidBrush( mAppDTO.uClrBgNormal );
		mHBrBgSelected = CreateSolidBrush( mAppDTO.uClrBgSelected );
		assert( mHBrWindow );
		assert( mHBrBgNormal );
		assert( mHBrBgSelected );
	}
	const std::array<int,2> aWHScrn = { GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),};
	assert( !mHwnd );
	mHwnd = CreateWindow( "ATZ:Helper_Class_SxCDPiD", szAppName, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0,
		int(aWHScrn[0] * 0.4f),
		int(aWHScrn[1] * 0.4f),
		NULL, NULL, NULL, NULL);
	if( !mHwnd ){
		return 0L;
	}
	SetWindowLongPtr( mHwnd, GWLP_USERDATA, (LONG_PTR)this );
	ShowWindow( mHwnd, nCmdShow ); //SW_SHOW
	if( mAppDTO.bTopmost ){
		SetWindowPos( mHwnd, HWND_TOPMOST, 0, 0, 0, 0,
				SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOOWNERZORDER );
	}
	if( mAppDTO.bTrayIcon ){
		initializeTrayIcon();
	}
	{
		assert(mHwnd); //WM_HOTKEY
		bool rs2;
		rs2 = !!RegisterHotKey( mHwnd, mActIdTabPrev, MOD_WIN|MOD_SHIFT, VK_TAB );
		assert( rs2 && "fYHcY78");
		rs2 = !!RegisterHotKey( mHwnd, mActIdTabNext, MOD_WIN, VK_TAB );
		assert( rs2 && "2K0lomV");
	}
	return 1L;
}
int AtzMainWindow::run2()
{
	registerHlprWndClass( GetModuleHandle(0) );
	bool rs2 = initInstance( GetModuleHandle(0), (mAppDTO.bStartVisible ? SW_SHOW : SW_HIDE) );
	assert(rs2);
	MSG msg;
	while( GetMessage( &msg, nullptr, 0, 0 ) ){
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
	return static_cast<int>( msg.wParam );
}
/*std::array<int,2> AtzMainWindow::getIconDimensions( HICON hIcon3 )
{
	if( !hIcon3 ){
		return {0,0,};
	}
	//GetSystemMetrics
	ICONINFO ici2;  //GetIconInfo( (HICON)IDI_APPLICATION, );
	memset( &ici2, 0, sizeof(ici2) );
	bool rs2 = !!GetIconInfo( hIcon3, &ici2 );
	assert( rs2 );

	BITMAP sbmp;
	memset( &sbmp, 0, sizeof(sbmp) );
	GetObject( ici2.hbmMask, sizeof(sbmp), &sbmp );

	printf("ATZ: WxH: %d*%d\n", (int)sbmp.bmWidth, (int)sbmp.bmHeight );

	return {0,0,};
}//*/
bool AtzMainWindow::
getLiveWindowListForTabbing( std::vector<SWndDt>* outp2 )
{
	hxdw_EnumWindows( [&]( HWND hwnd )->bool{
		if( hwnd == mHwnd )
			return 1L;
		char bfrClsn[256];
		GetClassName( hwnd, bfrClsn, sizeof(bfrClsn) );
		auto ir2 = std::find_if( aSWNeedles.begin(), aSWNeedles.end(),
			[&]( const std::pair<std::string,std::string>& inp )->bool{
				return inp.first == bfrClsn;  //0: continue_ itrtn.
			});
		if( ir2 != aSWNeedles.end() ){
			DWORD pid2 = 0;
			GetWindowThreadProcessId( hwnd, &pid2 );
			if( pid2 ){
				std::string path2 = hxdw_GetProcessBinaryPath( pid2 );
				std::string fn2 = hxdw_SplitPath( path2 ).second;
				if(!hxdw_StrCmpOpt( fn2.c_str(), ir2->second.c_str(), -1, "i" ) ){
					return 1L;  //1: continue_ itrtn.
				}
			}
		}
		std::string name3 = hxdw_GetWindowText( hwnd );
		std::string sr3 = name3;
		if( sr3.size() > 64 ){
			sr3.resize( 61 );
			sr3 += "...";
		}
		if( sr3.empty() ){
			sr3 = "\x20";
		}
		SWndDt wndd2;
		wndd2.title2     = sr3;
		wndd2.name2      = name3;
		wndd2.classname2 = bfrClsn;
		wndd2.hwnd2      = hwnd;
		wndd2.hWndIcon   = hxdw_GetWindowIcon( hwnd );
		outp2->push_back( wndd2 );
		return 1L;
	}, "zm");
	return 1L;
}
void AtzMainWindow::onScrollHotkeyAction( int idHotkey, bool bFromBackground )
{
	std::vector<SWndDt> wnds2;
	bool rs2 = getLiveWindowListForTabbing( &wnds2 );
	assert( rs2 );
	const std::array<int,2> aIconDmnsns = { GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), };
	{
		const int nMaxIndex = int( wnds2.empty() ? 0 : wnds2.size()-1 );
		mTabbingPos = bFromBackground ? 0 : mTabbingPos;
		if( idHotkey == mActIdTabNext ){
			mTabbingPos += 1;
			mTabbingPos = ( mTabbingPos > nMaxIndex ? 0 : mTabbingPos );
		}else{
			mTabbingPos -= 1;
			mTabbingPos = ( mTabbingPos < 0 ? nMaxIndex : mTabbingPos );
		}
		mTabbingPos = std::min<int>( mTabbingPos, nMaxIndex );
	}
	assert( mHwnd );
	HDC hdc2 = GetDC( mHwnd );
	assert( hdc2 );
	SetBkMode( hdc2, TRANSPARENT );
	{
		{
			RECT rc2;
			GetClientRect( mHwnd, &rc2 );
			//FillRect( hdc2, &rc2, (HBRUSH)(COLOR_WINDOW+1) );
			FillRect( hdc2, &rc2, mHBrWindow );
		}
		int xx2 = 8, yy2 = 0;
		auto ir2 = wnds2.begin();
		for( int ii2=0; ir2 != wnds2.end(); ++ir2, ii2++ ){
			std::string sr4 = ir2->title2;
			if( mTabbingPos == ii2 ){
				sr4 = std::string(" [") + sr4 + "]";
				mTabbingWnd = ir2->hwnd2;
			}else{
				sr4 = std::string(" ") + sr4 + "";
			}
			{
				DWORD pid2 = 0;
				GetWindowThreadProcessId( ir2->hwnd2, &pid2 );
				sr4 += " - " + std::to_string(pid2);
			}
			SIZE aTextSize = {0,0,};
			GetTextExtentPoint32( hdc2, sr4.c_str(), sr4.size(), &aTextSize );
			const int xx3 = xx2 + aIconDmnsns[0];
			{
				RECT rc3 = { xx3, yy2, xx3 + aTextSize.cx, yy2 + aTextSize.cy };
				//FillRect( hdc2, &rc3, ( mTabbingPos != ii2 ?
				//		(HBRUSH)(COLOR_MENU+1) :
				//		(HBRUSH)(COLOR_HIGHLIGHT+1) ) );
				FillRect( hdc2, &rc3, ( mTabbingPos != ii2 ?
						(HBRUSH)mHBrBgNormal :
						(HBRUSH)mHBrBgSelected ) );
			}
			if( mTabbingPos == ii2 ){
				//SetTextColor( hdc2, GetSysColor(COLOR_HIGHLIGHTTEXT) );  //COLORREF: 0x00bbggrr
				SetTextColor( hdc2, mAppDTO.uClrTextSelected );  //COLORREF: 0x00bbggrr
			}else{
				//SetTextColor( hdc2, GetSysColor(COLOR_MENUTEXT) );
				SetTextColor( hdc2, mAppDTO.uClrTextNormal );
			}
			TextOut( hdc2, xx3, yy2, sr4.c_str(), (int)sr4.size() );
			if( ir2->hWndIcon ){
				DrawIcon( hdc2, xx2, yy2, ir2->hWndIcon );
			}
			yy2 += std::max<int>( aIconDmnsns[1], aTextSize.cy );
		}
	}
	{	//
		// resize main_ window according to num of tabbing items, the windows list.
		//
		const std::array<int,2> aWHScrn2 = { GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),};
		int wgt2, hgt2;
		wgt2 = aWHScrn2[0] / 2;
		hgt2 = std::max<int>( int(aIconDmnsns[1] * wnds2.size()), aWHScrn2[1]/2 );
		hgt2 = std::min<int>( hgt2, aWHScrn2[1] );
		hxdw_SetWindowPosSize( mHwnd, -1, -1, wgt2, hgt2, "sc");

		const auto aWHWnd = hxdw_GetWindowSize( mHwnd );
		int xy2[2] = {
			(aWHScrn2[0] / 2 - aWHWnd[0] / 2) + 0,
			(aWHScrn2[1] / 2 - aWHWnd[1] / 2),};
		hxdw_SetWindowPosSize( mHwnd, xy2[0], xy2[1], -1, -1, "p");   //SetWindowPos
	}
	//WM_PAINT
	ReleaseDC( mHwnd, hdc2 );
}
