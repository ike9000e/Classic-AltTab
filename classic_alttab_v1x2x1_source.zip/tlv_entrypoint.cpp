#include "tlv_entrypoint.h"
#include <assert.h>
#include <memory>

const char* szAppName = "Classic AltTab Helper";
//
// /IGNORE:4075 - LNK4075: ignoring '/EDITANDCONTINUE' due to '/OPT:ICF' specification
//
int main( int argc, const char*const* argv )
{
	printf("ATZ: Starting... [OWQYjPB]\n");

	uint32_t uHKAltTabPassedWhat = 0;
	AtzAppDTO sAppDTO;
	for( int ii2=1; ii2 < argc; ii2++ ){
		std::string arg0 = argv[ii2];
		std::string arg1 = ( ii2+1 < argc ? argv[ii2+1] : "");
		int nArgAsInt = atoi( arg1.empty() || !isdigit(arg1[0]) ? "1" : arg1.c_str() );
		if( arg0 == "-bStartVisible" ){
			sAppDTO.bStartVisible = !!nArgAsInt;
		}else if( arg0 == "-bTopmost" ){
			sAppDTO.bTopmost = !!nArgAsInt;
		}else if( arg0 == "-bTrayIcon" ){
			sAppDTO.bTrayIcon = !!nArgAsInt;
		}else if( arg0 == "-bPrintWndNames2" ){
			sAppDTO.bPrintWndNames2 = !!nArgAsInt;
		}else if( arg0 == "-bShowExeName" ){
			sAppDTO.bShowExeName = !!nArgAsInt;
		}else if( arg0 == "-nMaxTitleLen" ){
			sAppDTO.nMaxTitleLen = nArgAsInt;
		}else if( arg0 == "-anLabelSeparator" ){
			sAppDTO.srLabelSeparator = arg1;
		}else if( arg0 == "-nWinListOmitMode" ){
			sAppDTO.nWinListOmitMode = nArgAsInt;
		}else if( arg0 == "-color_spec" ){
			// five colors, comma separated list, as RGB values.
			std::vector<std::string> parts2;
			hxdw_StrExplode( arg1.c_str(), parts2, {";",}, -1, "\x20\t", "");
			assert( !parts2.empty() && "Five RGB colors expected. Semicolon separated [9MH70GH]" );
			uint32_t* arr2[5] = { &sAppDTO.uClrWindow, &sAppDTO.uClrTextNormal, &sAppDTO.uClrTextSelected, &sAppDTO.uClrBgNormal, &sAppDTO.uClrBgSelected,};
			if( parts2.size() < sizeof(arr2)/sizeof(arr2[0]) ){
				parts2.resize( 5, "");
			}
			for( int ii2=0; ii2 < sizeof(arr2)/sizeof(arr2[0]); ii2++ ){
				if( !parts2[ii2].empty() ){
					*arr2[ii2] = hxdw_ConvColorStrFmtToRGBFmt( parts2[ii2].c_str(),
							"rgb-", "0x00BBGGRR");
				}
			}
		}else if( arg0 == "-anHKAltTab" ){
			uHKAltTabPassedWhat |= 0x1;
			sAppDTO.anHKAltTab = AtzStrToHKPair( arg1.c_str(), "-anHKAltTab" );
		}else if( arg0 == "-anHKAltShiftTab" ){
			uHKAltTabPassedWhat |= 0x2;
			sAppDTO.anHKAltShiftTab = AtzStrToHKPair( arg1.c_str(), "-anHKAltShiftTab" );
		}
	}
	if( uHKAltTabPassedWhat && uHKAltTabPassedWhat != (0x1+0x2) ){
		printf("WARNING:\n");
		printf("    Only one of the two, '-anHKAltTab' and '-anHKAltShiftTab',\n");
		printf("    not both, parameters were passed on the command line.\n");
		printf("    Typically you should specify both hotkey combinations using\n");
		printf("    aforementioned parameter names.\n");
	}

	if( sAppDTO.nWinListOmitMode == 10 ){
		//[Windows.UI.Core.CoreWindow] [TextInputHost.exe] [Microsoft Text Input Application]
		//[Progman] [explorer.exe] [Program Manager]
		//[ApplicationFrameWindow] [ApplicationFrameHost.exe] []
		//[ApplicationFrameWindow] [ApplicationFrameHost.exe] [Settings]
		sAppDTO.aWndListToOmit2.push_back(
			{ "","",0x0, "explorer.exe","",0x0, "","",ATZ_ESWF_EmptyNameIsMatch,});
		sAppDTO.aWndListToOmit2.push_back(
			{ "","",0x0, "explorer.exe","",0x0, "Program Manager","",0x0,});
		sAppDTO.aWndListToOmit2.push_back(
			{ "Windows.UI.Core.CoreWindow","",0x0, "","",0x0, "","",0x0,});
		sAppDTO.aWndListToOmit2.push_back(
			{ "","",0x0, "ApplicationFrameHost.exe","",0x0, "","",ATZ_ESWF_EmptyNameIsMatch,});
		sAppDTO.aWndListToOmit2.push_back(
			{ "","",0x0, "ApplicationFrameHost.exe","",0x0, "Settings","",0x0,});
		sAppDTO.aWndListToOmit2.push_back(
			{ "","",0x0, "ApplicationFrameHost.exe","",0x0, "Cortana","",0x0,});
	}else if( sAppDTO.nWinListOmitMode == 7 ){
		// Windows 7 specific, System windows that tabbing should
		// omit, class+exec:
		//     "Shell_TrayWnd", "explorer.exe",
		//     "Progman",       "explorer.exe",
		sAppDTO.aWndListToOmit2.push_back(
			{ "Shell_TrayWnd","",0x0, "explorer.exe","",0x0, "","",0x0,});
		sAppDTO.aWndListToOmit2.push_back(
			{ "Progman","",0x0,       "explorer.exe","",0x0, "","",0x0,});
	}
	if( !sAppDTO.srLabelSeparator.empty() ){
		sAppDTO.srLabelSeparator = ("\x20" + hxdw_TrimStr( sAppDTO.srLabelSeparator, "\x20\t", "", -1 ) + "\x20");
	}
	AtzMainWindow ti2( 0, 0, sAppDTO );
	ti2.run2();
	printf("ATZ: Exiting...\n" );
	return 0;
}
int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
		LPSTR lpCmdLine, int nCmdShow )
{
	std::vector<std::string> argv2; std::vector<const char*> argv3;
	argv3 = hxdw_GetCommandLine3( &argv2 );
	int rslt = main( (int)argv3.size(), &argv3[0] );
	return rslt;
}

AtzMainWindow::AtzMainWindow( int, int, const AtzAppDTO& sAppDTO_ )
	: mAppDTO(sAppDTO_)
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
}
AtzMainWindow::~AtzMainWindow()
{
	if( mIsInTray ){
		toggleWindowVisibility( 1L );
	}
	if( mNid.hWnd ){
		Shell_NotifyIcon( NIM_DELETE, &mNid );
		memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
}
	{
		DeleteObject( mHBrWindow );
		DeleteObject( mHBrBgNormal );
		DeleteObject( mHBrBgSelected );
		mHBrWindow = mHBrBgNormal = mHBrBgSelected = 0;
	}
}
void AtzMainWindow::toggleWindowVisibility( int bShow2 )
{
	assert( mHwnd );
	if( bShow2 == -1 ){
		bShow2 = !IsWindowVisible(mHwnd);
	}
	assert( bShow2 >= 0 && bShow2 <= 1 );
	if( !bShow2 ){
		ShowWindow(mHwnd, SW_HIDE);//SW_MINIMIZE
		mIsInTray = 1L;
	}else{
		ShowWindow(mHwnd, SW_SHOW);
		ShowWindow(mHwnd, SW_RESTORE);
		SetForegroundWindow(mHwnd);
		mIsInTray = 0L;
	}
}
LRESULT CALLBACK
WndProc2( HWND hWnd, UINT msg2, WPARAM wParam, LPARAM lParam )
{
	AtzMainWindow* this2 = (AtzMainWindow*)GetWindowLongPtr( hWnd, GWLP_USERDATA );
	if(this2){
		return this2->WndProc3( hWnd, msg2, wParam, lParam );
	}
	return DefWindowProc( hWnd, msg2, wParam, lParam );
}


void AtzMainWindow::onOwnModkeyUp()
{
	//mTabbingWnd,mOldTopWindow
	if( mTabbingWnd && mTabbingWnd != mHwnd ){
		//std::string sr2 = hxdw_GetWindowText( mTabbingWnd );
		//printf("ATZ: Resoring mTabbingWnd... [%s] [Eb7K27X]\n", sr2.c_str() );

		//ShowWindow( mTabbingWnd, SW_SHOW );
		ShowWindow( mTabbingWnd, SW_RESTORE );
		SetForegroundWindow( mTabbingWnd );
		mTabbingWnd = 0;
		toggleWindowVisibility( 0L );
	}
}
LRESULT AtzMainWindow::WndProc3( HWND hWnd, UINT msg2, WPARAM wParam, LPARAM lParam )
{
	if( msg2 == mWMTrayAnyMessageId ){
		if( AtzAny<int>( lParam, {WM_LBUTTONDOWN,WM_LBUTTONDBLCLK,} ) ){
			printf("ATZ: tray icon click.\n");
			toggleWindowVisibility( -1 );
		}
	}else if( msg2 == AtzMainWindow::mWMDestroyLv2Id ){
		DestroyWindow(hWnd);
	}
	switch(msg2){
	case WM_COMMAND:{
			const int wmId = LOWORD(wParam);
			switch( wmId ){
			default:
				return DefWindowProc( hWnd, msg2, wParam, lParam );
			}
		}
		break;
	case WM_DESTROY:
		printf("ATZ: Processing WM_DESTROY\n");
		PostQuitMessage(0);
		return 1L;
	case WM_KEYDOWN:{
			int nVirtKey = (int) wParam;    // virtual-key code
			if( nVirtKey == 'Q' || nVirtKey == VK_ESCAPE ){
				//if( GetAsyncKeyState(VK_CONTROL) & 0x8000 )
				int ans2 = MessageBox( hWnd, "Really quit?", szAppName, MB_OKCANCEL|MB_ICONQUESTION );
				if( ans2 == IDOK ){
					DestroyWindow(hWnd);
				}
			}
		}
		break;
	case WM_HOTKEY: {
			const int idHotKey = (int) wParam;
			//printf("WM_HOTKEY_, id:%d [YzfyFF2]\n", idHotKey );
			bool bFromBackground2 = 0L;
			const HWND hFgWindow = GetForegroundWindow();
			if( mHwnd != hFgWindow ){
				mOldTopWindow = hFgWindow;
				ShowWindow( mHwnd, SW_SHOW );
				ShowWindow( mHwnd, SW_RESTORE );
				SetForegroundWindow( mHwnd );
				bFromBackground2 = 1L;
			}
			onScrollHotkeyAction( idHotKey, bFromBackground2 );
		}
		break;
	case WM_KEYUP:{
			const int nVirtKey = (int) wParam;
			if( hxdw_IsVirtKeyAlsoModKey( nVirtKey )){
				bool bOk = 1L;
				for( auto ir2 = mAModkeyUsing.begin(); ir2 != mAModkeyUsing.end(); ++ir2 ){
					if( hxdw_TestKeysDown( { *ir2,}, "a") ){
						bOk = 0L;
						break;
					}
				}
				if( bOk ){
					onOwnModkeyUp();
				}
			}
			//printf("nVirtKey: %d\n", nVirtKey );
		}
		break;
/*	case WM_PAINT:{
			static int cnt2 = 0;
			printf("WM_PAINT, %d\n", cnt2++ );
			PAINTSTRUCT pst2;
			HDC hdc3 = BeginPaint( hWnd, &pst2 );
			EndPaint( hWnd, &pst2 );
			return 0;
		}
		break;//*/
	default:
		return DefWindowProc( hWnd, msg2, wParam, lParam );
	}
	return 0;
}
ATOM AtzMainWindow::registerHlprWndClass( HINSTANCE hInstance )
{
	WNDCLASSEX wcex;
	memset( &wcex, 0, sizeof(wcex) );
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc2; //(WNDPROC)
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
//	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
//	wcex.hbrBackground = (HBRUSH) CreateSolidBrush( RGB(255,0,0) );
	wcex.hbrBackground = (HBRUSH)0;
	wcex.lpszMenuName = "ATZ:Helper_Class_SxCDPiD";
	wcex.lpszClassName = "ATZ:Helper_Class_SxCDPiD";
	wcex.hIcon = LoadIcon( nullptr, IDI_ASTERISK );
	return RegisterClassEx(&wcex);
}
void AtzMainWindow::initializeTrayIcon()
{
	memset( &mNid, 0, sizeof(NOTIFYICONDATA) );
	mNid.cbSize = sizeof(NOTIFYICONDATA);
	mNid.hWnd   = mHwnd;
	mNid.uID    = 1001;// uId ? ++uId : uId = 1;
	mNid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	mNid.uCallbackMessage = mWMTrayAnyMessageId;   //WM_USER+0x210
	mNid.hIcon  = hxdw_GetWindowIcon( mHwnd );
	assert(mNid.hIcon);
	//
	snprintf( mNid.szTip, sizeof(mNid.szTip), "%s", hxdw_GetWindowText( mHwnd ).c_str() );
	Shell_NotifyIcon( NIM_ADD, &mNid );
}
bool AtzMainWindow::initInstance( HINSTANCE hInstance, int nCmdShow )
{
	{
		assert( !mHBrWindow && !mHBrBgNormal && !mHBrBgSelected );
		mHBrWindow = CreateSolidBrush( mAppDTO.uClrWindow );
		mHBrBgNormal = CreateSolidBrush( mAppDTO.uClrBgNormal );
		mHBrBgSelected = CreateSolidBrush( mAppDTO.uClrBgSelected );
		assert( mHBrWindow );
		assert( mHBrBgNormal );
		assert( mHBrBgSelected );
	}
	const std::array<int,2> aWHScrn = { GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),};
	assert( !mHwnd );
	mHwnd = CreateWindow( "ATZ:Helper_Class_SxCDPiD", szAppName, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0,
		int(aWHScrn[0] * 0.4f),
		int(aWHScrn[1] * 0.4f),
		NULL, NULL, NULL, NULL);
	if( !mHwnd ){
		return 0L;
	}
	SetWindowLongPtr( mHwnd, GWLP_USERDATA, (LONG_PTR)this );
	ShowWindow( mHwnd, nCmdShow ); //SW_SHOW
	if( mAppDTO.bTopmost ){
		SetWindowPos( mHwnd, HWND_TOPMOST, 0, 0, 0, 0,
				SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOOWNERZORDER );
	}
	if( mAppDTO.bTrayIcon ){
		initializeTrayIcon();
	}
	{
		assert(mHwnd); //WM_HOTKEY
		bool rs2; //VK_LWIN,VK_MENU
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabPrev, MOD_WIN|MOD_SHIFT, VK_TAB );
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabPrev, MOD_WIN|MOD_ALT, 'Z' );
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabPrev, MOD_ALT|MOD_SHIFT, VK_CAPITAL );
		// 192 = tilde, aka. grave, aka. accent.
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabPrev, MOD_ALT|MOD_SHIFT, 192 );
		rs2 = !!RegisterHotKey( mHwnd, mActIdTabPrev,
			mAppDTO.anHKAltShiftTab.first,
			mAppDTO.anHKAltShiftTab.second );
		assert( rs2 && "fYHcY78");
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabNext, MOD_WIN, VK_TAB );
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabNext, MOD_WIN|MOD_ALT, 'X' );
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabNext, MOD_ALT, VK_CAPITAL );
	//	rs2 = !!RegisterHotKey( mHwnd, mActIdTabNext, MOD_ALT, 192 );
		rs2 = !!RegisterHotKey( mHwnd, mActIdTabNext,
			mAppDTO.anHKAltTab.first,
			mAppDTO.anHKAltTab.second );
		assert( rs2 && "2K0lomV");
	}
	mAModkeyUsing = hxdw_ConvModKeysToVirtKeyList( mAppDTO.anHKAltTab.first | mAppDTO.anHKAltShiftTab.first, "" );
	return 1L;
}
int AtzMainWindow::run2()
{
	registerHlprWndClass( GetModuleHandle(0) );
	bool rs2 = initInstance( GetModuleHandle(0), (mAppDTO.bStartVisible ? SW_SHOW : SW_HIDE) );
	assert(rs2);
	MSG msg;
	while( GetMessage( &msg, nullptr, 0, 0 ) ){
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}
	return static_cast<int>( msg.wParam );
}
/*std::array<int,2> AtzMainWindow::getIconDimensions( HICON hIcon3 )
{
	if( !hIcon3 ){
		return {0,0,};
	}
	//GetSystemMetrics
	ICONINFO ici2;  //GetIconInfo( (HICON)IDI_APPLICATION, );
	memset( &ici2, 0, sizeof(ici2) );
	bool rs2 = !!GetIconInfo( hIcon3, &ici2 );
	assert( rs2 );

	BITMAP sbmp;
	memset( &sbmp, 0, sizeof(sbmp) );
	GetObject( ici2.hbmMask, sizeof(sbmp), &sbmp );

	printf("ATZ: WxH: %d*%d\n", (int)sbmp.bmWidth, (int)sbmp.bmHeight );

	return {0,0,};
}//*/
bool AtzMainWindow::
getLiveWindowListForTabbing( std::vector<SWndDt>* outp2 )
{
	if( mAppDTO.bPrintWndNames2 ){
		printf("ATZ: INFO: Showing window names.\n");
	}
	hxdw_EnumWindows( [&]( HWND hwnd )->bool{
		if( hwnd == mHwnd )
			return 1L;

		AtzWCETInfos wcis2;
		AtzGetWindowClassInfos( hwnd, &wcis2 );
		if( mAppDTO.bPrintWndNames2 ){
			printf("    [%s] [%s] [%s]\n",
				wcis2.srClassName2.c_str(), wcis2.srExecBaseName.c_str(),
				wcis2.srWndTitle.c_str() );
		}
		if( AtzTestWindowForSWTabbing( mAppDTO.aWndListToOmit2, wcis2 ) ){
			return 1L;
		}
		std::string srWTitle = wcis2.srWndTitle;
		if( srWTitle.empty() ){
			srWTitle = "EMPTY NAME";
		}
		std::string srLbl;
		if( mAppDTO.bShowExeName ){
			srLbl += ( std::string(srLbl.empty()?"":"\x20") + "" + wcis2.srExecBaseName + "");
		}
		const std::string sep2 = mAppDTO.srLabelSeparator;
		srLbl += ( std::string(srLbl.empty()?"":sep2.c_str()) + srWTitle );
		if( srLbl.size() > mAppDTO.nMaxTitleLen ){
			assert( mAppDTO.nMaxTitleLen > 3 );
			srLbl.resize( mAppDTO.nMaxTitleLen - 3 );
			srLbl += "...";
		}
		SWndDt wndd2;
		wndd2.title2     = srLbl;
		wndd2.name2      = wcis2.srWndTitle;
		wndd2.classname2 = wcis2.srClassName2; // bfrClsn;
		wndd2.hwnd2      = hwnd;
		wndd2.hWndIcon   = hxdw_GetWindowIcon( hwnd );
		wndd2.pid3       = wcis2.pid4;
		outp2->push_back( wndd2 );
		return 1L;
	}, "zm"); //"zm"
	return 1L;
}
void AtzMainWindow::onScrollHotkeyAction( int idHotkey, bool bFromBackground )
{
	std::vector<SWndDt> wnds2;
	bool rs2 = getLiveWindowListForTabbing( &wnds2 );
	assert( rs2 );
	const std::array<int,2> aIconDmnsns = { GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON), };
	{
		const int nMaxIndex = int( wnds2.empty() ? 0 : wnds2.size()-1 );
		mTabbingPos = bFromBackground ? 0 : mTabbingPos;
		if( idHotkey == mActIdTabNext ){
			mTabbingPos += 1;
			mTabbingPos = ( mTabbingPos > nMaxIndex ? 0 : mTabbingPos );
		}else{
			mTabbingPos -= 1;
			mTabbingPos = ( mTabbingPos < 0 ? nMaxIndex : mTabbingPos );
		}
		mTabbingPos = std::min<int>( mTabbingPos, nMaxIndex );
	}
	assert( mHwnd );
	HDC hdc2 = GetDC( mHwnd );
	assert( hdc2 );
	SetBkMode( hdc2, TRANSPARENT );
	{
		{
			RECT rc2;
			GetClientRect( mHwnd, &rc2 );
			//FillRect( hdc2, &rc2, (HBRUSH)(COLOR_WINDOW+1) );
			FillRect( hdc2, &rc2, mHBrWindow );
		}
		int xx2 = 8, yy2 = 0;
		auto ir2 = wnds2.begin();
		for( int ii2=0; ir2 != wnds2.end(); ++ir2, ii2++ ){
			std::string srVisibleText = ir2->title2;
			const bool bIsCurrent = ( mTabbingPos == ii2 );
			if( bIsCurrent ){
				mTabbingWnd = ir2->hwnd2;
			}
			const std::string sep2 = mAppDTO.srLabelSeparator;
			srVisibleText += sep2 + std::to_string( ir2->pid3 );
			//
			const std::string srMargin2 = "\x20\x20";
			if( bIsCurrent ){
				srVisibleText = ( srMargin2 + "[" + srVisibleText + "]" + srMargin2 );
			}
			SIZE aTextSize = {0,0,};
			GetTextExtentPoint32( hdc2, srVisibleText.c_str(), srVisibleText.size(), &aTextSize );
			int xx3 = xx2 + aIconDmnsns[0];
			if( !bIsCurrent ){
				SIZE aLMargin = {0,0,};
				GetTextExtentPoint32( hdc2, srMargin2.c_str(), srMargin2.size(), &aLMargin );
				xx3 += aLMargin.cx;
			}
			{
				RECT rc3 = { xx3, yy2, xx3 + aTextSize.cx, yy2 + aTextSize.cy };
				FillRect( hdc2, &rc3, ( mTabbingPos != ii2 ?
						(HBRUSH)mHBrBgNormal :
						(HBRUSH)mHBrBgSelected ) );
			}
			if( mTabbingPos == ii2 ){
				SetTextColor( hdc2, mAppDTO.uClrTextSelected );  //COLORREF: 0x00bbggrr
			}else{
				SetTextColor( hdc2, mAppDTO.uClrTextNormal );
			}
			TextOut( hdc2, xx3, yy2, srVisibleText.c_str(), (int)srVisibleText.size() );
			if( ir2->hWndIcon ){
				DrawIcon( hdc2, xx2, yy2, ir2->hWndIcon );
			}
			yy2 += std::max<int>( aIconDmnsns[1], aTextSize.cy );
		}
	}
	{	//
		// resize main_ window according to num of tabbing items, the windows list.
		//
		const std::array<int,2> aWHScrn2 = { GetSystemMetrics( SM_CXSCREEN ), GetSystemMetrics( SM_CYSCREEN ),};
		int wgt2, hgt2;
		wgt2 = aWHScrn2[0] / 2;
		hgt2 = std::max<int>( int(aIconDmnsns[1] * wnds2.size()), aWHScrn2[1]/2 );
		hgt2 = std::min<int>( hgt2, aWHScrn2[1] );
		hxdw_SetWindowPosSize( mHwnd, -1, -1, wgt2, hgt2, "sc");

		const auto aWHWnd = hxdw_GetWindowSize( mHwnd );
		int xy2[2] = {
			(aWHScrn2[0] / 2 - aWHWnd[0] / 2) + 0,
			(aWHScrn2[1] / 2 - aWHWnd[1] / 2),};
		hxdw_SetWindowPosSize( mHwnd, xy2[0], xy2[1], -1, -1, "p");   //SetWindowPos
	}
	//WM_PAINT
	ReleaseDC( mHwnd, hdc2 );
}
std::pair<int32_t,int32_t>
AtzStrToHKPair( const char* inp, const char* szVarname )
{
	std::vector<std::string> parts2;
	hxdw_StrExplode( inp, *&parts2, {",",}, -1, "\x20\t", "" );
	if( parts2.size() < 2 ){
		printf("ERROR: Expected 2 parts separated by comma to be passed in '%s' [5FA5Dd]", szVarname );
		assert( 0 );
	}
	return {
		static_cast<int32_t>(atoi( parts2[0].c_str() )),
		static_cast<int32_t>(atoi( parts2[1].c_str() )),
	};
}
/*bool AtzWCETInfos::isEmpty2()const
{
	if( srClassName2.empty() && srExecBaseName.empty() && srWndTitle.empty() )
		return 1L;
	return 0L;
}//*/
bool AtzSWNeedle::isEmpty3()const
{
	if(
			srClassName3.empty() &&
			srClassNeedle3.empty() &&
			!uCNFlags &&
			srExecName3.empty() &&
			srExecNeedle3.empty() &&
			!uENFlags &&
			srTitleName3.empty() &&
			srTitleNeedle3.empty() &&
			!uTNFlags &&
			1 ){
		return 1L;
	}
	return 0L;
}
bool AtzGetWindowClassInfos( HWND hwnd, AtzWCETInfos* outp )
{
	char bfrClsn[256];
	GetClassName( hwnd, bfrClsn, sizeof(bfrClsn) );
	outp->srClassName2 = bfrClsn;
	{
		DWORD pid2 = 0;
		GetWindowThreadProcessId( hwnd, &pid2 );
		if( pid2 ){
			std::string path2 = hxdw_GetProcessBinaryPath( pid2 );
			std::string fn3 = hxdw_SplitPath( path2 ).second;
			outp->srExecBaseName = fn3;
		}
		outp->pid4 = pid2;
	}
	outp->srWndTitle = hxdw_GetWindowText( hwnd );
	return 1L;
}
bool AtzTestWindowForSWTabbing(
		const std::vector<AtzSWNeedle>& aWndNeedlesToOmit3,
		const AtzWCETInfos& wcis3 )
{
	auto a = std::find_if( aWndNeedlesToOmit3.begin(), aWndNeedlesToOmit3.end(),
		[&]( const AtzSWNeedle& needle2 )->bool{
			assert( !needle2.isEmpty3() );
			uint32_t uMatch2 = 0L;
			{
				if( !needle2.srClassName3.empty() ){
					if( wcis3.srClassName2 == needle2.srClassName3 ){
						uMatch2 |= 0x1;
					}
				}else if( !needle2.srClassNeedle3.empty() ){
					if( hxdw_StrSearch2( wcis3.srClassName2.c_str(), -1, needle2.srClassNeedle3.c_str(), -1, "i") ){
						uMatch2 |= 0x1;
					}
				}else{
					uMatch2 |= 0x1;
				}
			}{
				if( !needle2.srExecName3.empty() ){
					if( wcis3.srExecBaseName == needle2.srExecName3 ){
						uMatch2 |= 0x2;
					}
				}else if( !needle2.srExecNeedle3.empty() ){
					if( hxdw_StrSearch2( wcis3.srExecBaseName.c_str(), -1, needle2.srExecNeedle3.c_str(), -1, "i") ){
						uMatch2 |= 0x2;
					}
				}else{
					uMatch2 |= 0x2;
				}
			}{
				if( !needle2.srTitleName3.empty() ){
					if( wcis3.srWndTitle == needle2.srTitleName3 ){
						uMatch2 |= 0x4;
					}
				}else if( !needle2.srTitleNeedle3.empty() ){
					if( hxdw_StrSearch2( wcis3.srWndTitle.c_str(), -1, needle2.srTitleNeedle3.c_str(), -1, "i") ){
						uMatch2 |= 0x4;
					}
				}else if( needle2.uTNFlags & ATZ_ESWF_EmptyNameIsMatch ){
					if( wcis3.srWndTitle.empty() ){
						uMatch2 |= 0x4;
					}
				}else{
					uMatch2 |= 0x4;
				}
			}
			return ( uMatch2 >= 0x1+0x2+0x4 );
	});
	return ( a != aWndNeedlesToOmit3.end() ); //1L: if found.
}

