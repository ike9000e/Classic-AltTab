#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <stdio.h>
#include <vector>
#include <array>
#include <algorithm>
#include <functional>
#include <cstring>
#include <assert.h>
#include <windows.h>

struct HxdwPrintAdp; struct hxdw_IniData2;
struct HxdwSizeAdp;

std::string hxdw_TrimStr( const std::string& inp, const std::string& charset2, const char* flags2, int limit2 );
int         hxdw_StrCmpOpt( const char* a, const char* b, int num = -1, const char* flags2 = "" );
int         hxdw_StrCmpOpt3( const char* a, const char* b, size_t num, const char* flags2 );
const char* hxdw_StrSearch2( const char* inp, size_t len2, const char* needle2, size_t len4, const char* flags2 );
const char* hxdw_StrSearch3( const char* inp, const char* end_, const char* needle2, const char* flags2 );
std::string hxdw_StrToLower( std::string inp );
bool        hxdw_TestCharClass( int inp, const char* flags2 );
std::string hxdw_StrPrintf( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
bool        hxdw_StdPrint2( const char* msg2 );
bool        hxdw_EndsWith( const char* a, int len2, const char* b, int len3, const char* flags2 );
bool        hxdw_StrExplode( const char* inp, std::vector<std::string>& parts2, const std::vector<std::string> lsGlueItems, int nLimit = -1, const char* szTrimLR = nullptr, const char* flags3 = "" );
void        hxdw_StrExplode2( const char* inp, std::function<void(const char*, int len)> calbNewPart, const std::vector<std::string> lsGlueItems, int nLimit, const char* szTrimLR );
std::string hxdw_StrImplode( const std::vector<std::string>& parts2, const std::string glue2, const char* szTrimLR = nullptr );
double      hxdw_StrToDbl( const char* inp, char** endp = 0 );
std::string hxdw_HexEncode( const void* data_, size_t len_, const char* flags2 );
auto        hxdw_HexDecode( const char* data_, int len_ ) -> std::vector<uint8_t>;
bool        hxdw_FileExists( const char* fname );
auto        hxdw_SplitExt( std::string inp ) -> std::pair<std::string,std::string>;
auto        hxdw_SplitPath( std::string inp ) -> std::pair<std::string,std::string>;
std::string hxdw_PathJoin( const std::string& dir_, const std::string& basename_, const std::string& ext_ );
bool        hxdw_IsWithPathPart( std::string pathname );
bool        hxdw_IsPathCDRelative( const std::string& pathname );
bool        hxdw_IsAbsolutePath( const std::string& pathname );
std::string hxdw_StrReplace( std::string str, const std::string& from2, const std::string& to2 );
bool        hxdw_IsDir( const char* pathname );
bool        hxdw_MkdirRcv( std::string srDirname );
bool        hxdw_Mklink( std::string srSymlinkFileName, std::string srTarget, std::string flags2 );
std::string hxdw_GetTextFileContents( const char* fname );
auto        hxdw_GetBinaryFileContents( const char* fname, size_t nMaxRead ) -> std::vector<uint8_t>;
bool        hxdw_ReadBinaryFileContents( const char* fname, HxdwSizeAdp nMaxRead2, std::function<bool( const uint8_t*, uint32_t len )> calb2, uint32_t uStartPos, uint32_t nRqBufSize );
bool        hxdw_PutFileContents( const std::string filename, const char* data2, int nNumBytes, const char* flags2 );
bool        hxdw_GetTextLinesFromFile( const char* fname, std::vector<std::string>* lines2 );
int         hxdw_GetFileSize( const char* fname );
uint64_t    hxdw_GetFileSize2( const char* fname );
bool        hxdw_Fseek64( FILE* fp2, uint64_t offset2 );
std::string hxdw_GetArgvByName( const std::vector<std::string> argnames2, int argc2, const char*const* argv2, const char* szFlags = "" );
uint64_t    hxdw_GetTimeTicksUs();
uint64_t    hxdw_GetTimeTicksMs();
uint64_t    hxdw_GetPosixTimeUs();
auto        hxdw_GetWallClockTime() -> SYSTEMTIME;
auto        hxdw_GetSystemTime() -> SYSTEMTIME;
bool        hxdw_SendKeyboardInput( const std::vector< std::pair<int,int> >& aKeys, const char* flags2 );
bool        hxdw_SendMouseDeltaInput( std::pair<int,int> xyDelta );
bool        hxdw_SendMouseButtonInput( const std::vector< std::pair<int,int> >& aMButtons );
bool        hxdw_SendMouseWheelInput( int nWheelDelta );
std::string hxdw_StrTruncate( std::string inp, int maxlen, const std::string dots2 = "..." );
std::string hxdw_StrLTruncate( std::string inp, int maxlen, const std::string dots2 = "..." );
bool        hxdw_CopyFilesToDir( const std::vector<std::pair<std::string,std::string> >& inp, const char* szDstDir, std::string* err2 );
DWORD       hxdw_GetBinaryType( const std::string srFname );
bool        hxdw_DeleteFilesWithRollback( const std::vector<std::string> filenames, std::string* err2 );
bool        hxdw_SendDropFilesToWnd( HWND hwnd, const std::vector<std::string>& fnames, const char* flags2 = "" );
std::string hxdw_OpenFileNameWithUI( const char* szDefaultFn, const char* szTitle, const char* szExtFilter, HWND hwParent );
std::string hxdw_BrowseForFolder( HWND hwParent, std::string title2, std::string folder2 );
std::string hxdw_GetWindowText( HWND hwnd );
bool        hxdw_CaptureWindowScreenToFile( const char* filename, HWND hwnd, const char* flgs );
bool        hxdw_GetWindowPixels( HWND hwnd, std::function<bool( const RGBQUAD* pPixels2, int w, int h )> calb6 );
bool        hxdw_GetDirFilesRcv( const char* szDir, std::vector<std::string>* fnames, const char* szFlags );
bool        hxdw_EnumDirFilesRcv( const char* szDir, const char* szFlags, std::function<short( const char* szFname, int falgs3 )> calb4 );
std::string hxdw_StrWcsToUtf8a( const wchar_t* buffer, int len );
auto        hxdw_StrUtf8aToWcs( const char* inp, int len ) -> std::wstring;
int         hxdw_GetJuncPointW( wchar_t** path1, const wchar_t* path2, int* relative, int* linktype );
std::string hxdw_ReadLink( const std::string pathname, bool* bIsRelative = 0 );
std::string hxdw_GetSymlinkFullPath( const std::string pathname );
bool        hxdw_IsCurrentProcessElevated();
auto        hxdw_ParseINIFile( const char* szIniFname ) -> hxdw_IniData2;
auto        hxdw_ParseINIData( const char* data2, int size_ ) -> hxdw_IniData2;
std::string hxdw_GetLastError();
bool        hxdw_LoadRemoteProcessDll( DWORD pid2, const char* szDllFileName, std::string* err, const char* flags2 );
std::string hxdw_GetCurrentDirectory();
std::string hxdw_GetCurrentExecutableFilePath();
HMODULE     hxdw_GetModuleHandleFromAddr( const void* addr );
std::string hxdw_GetModuleFileName( HMODULE hDll );
std::string hxdw_GetModuleFileNameFromAddr( const void* addr );
HWND        hxdw_FindWindowByCaptionPart( const char* szNeedle, const char* flags2 );
HWND        hxdw_FindMainWindowGivenPID( DWORD process_id, const char* flags2 );
bool        hxdw_IsMainWindow( HWND hwnd, const char* flags2 = "" );
bool        hxdw_EnumWindows( std::function<bool(HWND)> calb3, const char* flags2 );
HICON       hxdw_GetWindowIcon( HWND hWnd );
auto        hxdw_GetWindowSize( HWND hwnd ) -> std::array<int,2>;
auto        hxdw_GetWindowDecorationSize( HWND hwnd ) -> std::array<std::array<int,2>,2>;
bool        hxdw_SetWindowPosSize( HWND hwnd, int nXPos, int nYPos, int nWidth, int nHeight, const char* flags2 );
std::string hxdw_NormalizeNTPath( const char* inp );
auto        hxdw_GetCommandLine2() -> std::vector<std::string>;
auto        hxdw_GetCommandLine3( std::vector<std::string>* outp ) -> std::vector<const char*>;
uint32_t    hxdw_ConvColorStrFmtToRGBFmt( const char* inp, const char* fmt4, const char* fmt0x );
HANDLE      hxdw_CreateThreadSimple( std::function<uint32_t()> calb2, uint32_t uDelayMs );
bool        hxdw_TestKeysDown( const std::vector<int32_t>& keylist, const char* flags2 );
int32_t     hxdw_ConvModKeyToVirtKey( int32_t nModKey );
int32_t     hxdw_ConvVirtKeyToModKey( int32_t nVirtKey );
auto        hxdw_GetModKeyToVirtKeyMap() -> const std::vector<std::pair<std::vector<int32_t>,std::vector<int32_t>>>&;
bool        hxdw_IsVirtKeyAlsoModKey( int32_t nVirtKey );
auto        hxdw_ConvModKeysToVirtKeyList( int32_t nModKeyAsFlags, const char* flags2 ) -> std::vector<int32_t>;

/// Adaptor for input vector element parameter for hxdw_StrPrintf().
struct HxdwPrintAdp {
	HxdwPrintAdp( const std::string& inp ) {srVal = inp; nVal = 0;}
	HxdwPrintAdp( int64_t inp ) {srVal = ""; nVal = inp; bStr = 0; }
	HxdwPrintAdp( const char* a, int64_t b ) {srVal = a; nVal = b; bStr = (a?1:0);}
private:
	std::string srVal;
	int64_t nVal;
	bool bStr = 1;
	friend std::string hxdw_StrPrintf( const char* fmt, const std::vector<HxdwPrintAdp> args4 );
};

using hxdw_IniSection = std::pair< std::string, std::vector<std::pair<std::string,std::string> > >;
using hxdw_IniData3 = std::vector< hxdw_IniSection >;
/// Used by hxdw_ParseINIFile().
struct hxdw_IniData2{
	hxdw_IniData3 sections2;
	bool        eachSection( std::function<bool( const hxdw_IniSection& )> calb2 )const;
	bool        eachVariable( const std::vector<std::string> sectnames, std::function<bool( const char* secname, const char* kname, const char* value2 )> calb2 )const;
	std::string getValue( const char* sec2, const char* kname, const char* default2 = nullptr )const;
	bool        setValue( const char* sec2, const char* kname, const char* value3 );
	auto        getSectionsByNamePrefix( const char* szPrefix, const char* flags2 = "" )const -> std::vector<std::string>;
	auto        getAsString()const -> std::string;
	bool        updateINIValues( std::function<bool(std::string* sectionn, std::string* varnamee, std::string* valuee)> calb2 );
	static bool updateINIFileValues( const char* szINIFname, std::function<bool(std::string* sectionn, std::string* varnamee, std::string* valuee)> calb2 );
	bool        updateFrom( const hxdw_IniData2& otherr );
	bool        isINIEmpty()const;
};

enum{
	/// File attributes used with hxdw_EnumDirFilesRcv() on its callbacl function.
	HXDW_FA_Dir = 0x1,
	HXDW_FA_Symlink = 0x1,
};

struct HxPrintf_T_1
{
	template<class...Ts>
	void operator()( Ts...args ){
		dbg_print_va( args... );
	}
	static void setGlobalLogLevel( int llevel ) {LLevel = llevel;}
	static int  getGlobalLogLevel() {return LLevel;}
protected:
	virtual void printData( const std::string& inp ) {
		printf("%s", inp.c_str() );
	}
private:
	void resetItself(){
		*this = HxPrintf_T_1();
	}
	template<class...Ts>
	void dbg_print_va( Ts...args ){
		resetItself();
		decompose2( args... );
		generateData();
		printData( Outp );
	}
	void decompose2() {}
	template<class T, class...Ts>
	void decompose2( T arg1, Ts...args ){
		fn_vari( arg1 );
		decompose2( args... );
	}
	void fn_vari() {}
	template<class T>   // overload enabled via the return type.
	typename std::enable_if< std::is_integral<T>::value || std::is_floating_point<T>::value, T>::type
	fn_vari( T inp ){
		Args2.push_back( std::to_string(inp) );
		return 0;
	}
	void fn_vari( const char* inp ){
		if( !iChars ){
			Fmt = inp;
		}else{
			Args2.push_back(inp);
		}
		++iChars;
	}
	void generateData() {
		const char* sz2 = Fmt.c_str(), *sz3;
		const char* endd = sz2 + Fmt.size();
		for( size_t ii2=0; (sz3 = std::strchr(sz2,'%')); ){
			if( &sz3[1] < endd && std::strchr( "ads", sz3[1] ) ){
				Outp.append( sz2, sz3-sz2 );
				Outp.append( ii2 < Args2.size() ? Args2[ii2] : ""  );
				++ii2;
				sz2 = sz3+2;
			}else{
				Outp.append( sz2, sz3-sz2+1 );
				sz2 = sz3+1;
			}
		}
		Outp += sz2;
	}
private:
	static int LLevel;
	int iChars = 0;
	std::string Fmt, Outp;
	std::vector<std::string> Args2;
};

/**
	Prints formated string from variadic argument list.
	Intended to be used using call to the operator parentheses.
	In addition, allows std::string to be used as one of the arguments.
	Default implementation uses printf() to output the final string.
	Virtual protected member function printData() may be reimplemented|overriden
	to output the string other way.

	\code
		// Example.
		HxPrintfBase HxPrintf2;
		HxPrintf2("v:%d, s:[%5s] s:[%s]\n", 1+2, "abc", std::string("def") );
	\endcode
*/
struct HxPrintfBase
{
	template<class...Ts>
	void operator()( const char* fmt3, Ts...args ){
		printfVA( 0, fmt3, args... );
	}
	template<class...Ts>
	void operator()( uint32_t nLoglevel, const char* fmt3, Ts...args ){
		printfVA( nLoglevel, fmt3, args... );
	}
	static void setGlobalLogLevel( uint32_t llevel );
protected:
	virtual void printData( const std::string& inp );
private:
	template<class...Ts>
	void printfVA( uint32_t nLoglevel, const char* fmt3, Ts...args ){
		// The higher function loglevel, the lower chance this call is logged.
		if( nLoglevel <= LGlobalLevel ){
			std::vector<std::string> fmts3;
			convFmtToArr( fmt3, fmts3 );
			assert( sizeof...(args)+1 == fmts3.size() );
			std::string outp2 = fmts3[0];
			sprintfRcv( fmts3, outp2, 0, args... );
			printData( outp2 );
		}
	}
	void convFmtToArr( const char* fmt3, std::vector<std::string>& fmts4 );
	void sprintfRcv( const std::vector<std::string>&, std::string&, int ) {}
	template<class T, class...Ts>
	void sprintfRcv( const std::vector<std::string>& fmts4, std::string& outp3, int ii2, T arg1, Ts...args ){
		sprintfArg<T>( fmts4, outp3, ii2, arg1 );
		sprintfRcv( fmts4, outp3, ii2+1, args... );
	}
	// overloads are enabled via a template parameter.
	template<class T, typename std::enable_if<
			std::is_fundamental<T>::value ||
			std::is_same<T,const char*>::value, T>::type* = nullptr>
	void sprintfArg( const std::vector<std::string>& fmts4, std::string& outp3, int ii3, T arg_1 ){
		assert( ii3+1 < static_cast<int>( fmts4.size() ) );
		const std::string fmt4 = fmts4[ii3+1];
		char dmy0[1];
		int num = snprintf( dmy0, 0, fmt4.c_str(), arg_1 ); //calculates required buffer size.
		std::vector<char> bfr3;
		bfr3.resize( num+2 );
		snprintf( &bfr3[0], bfr3.size(), fmt4.c_str(), arg_1 );
		outp3 += &bfr3[0];
	}
	// overload for the 'std::string' enabled via a template parameter.
	template<class T, typename std::enable_if<std::is_same<T,std::string>::value, T>::type* = nullptr>
	void sprintfArg( const std::vector<std::string>& fmts4, std::string& outp3, int ii3, const std::string& arg_1 ){
		sprintfArg<const char*>( fmts4, outp3, ii3, arg_1.c_str() );
	}
private:
	static uint32_t LGlobalLevel;
};

struct HxdwSizeAdp {
	bool      bUnlimited = 0L;
	uint64_t  uSize = 0L;
	HxdwSizeAdp() = delete;
	HxdwSizeAdp( uint64_t uSize_ );
	HxdwSizeAdp( float placeholder_ );
};
/*template<class Txx>
bool hxdw_Any( Txx needle2, std::vector<Txx> arr2 )
{
	auto a = std::find( arr2.begin(), arr2.end(), needle2 );
	return a != arr2.end();
}//*/
