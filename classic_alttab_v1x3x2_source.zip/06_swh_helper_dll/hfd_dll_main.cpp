#include "hfd_dll_main.h"
#include <stdio.h>
#include "hxdw_utils.h"
//#include <ctime> //std::time()
//#include <windows.h>
//#include <mmsystem.h>   //PlaySound()

SwhhData2* Swhh2 = nullptr;
uint32_t dll_dummy_o1009qv3w()
{
	return 42;
}

BOOL WINAPI DllMain( HINSTANCE hInst, DWORD dwReason, LPVOID )
{
	switch( dwReason ){
	case DLL_PROCESS_ATTACH:{
			assert( !Swhh2 );
			Swhh2 = new SwhhData2;
			{
				Swhh2->srSelfExePath     = hxdw_GetCurrentExecutableFilePath();
				Swhh2->srSelfExeBaseName = hxdw_SplitPath( Swhh2->srSelfExePath ).second;
				Swhh2->srSelfDllPath     = hxdw_GetModuleFileNameFromAddr( DllMain );
				Swhh2->srSelfDllBaseName = hxdw_SplitPath( Swhh2->srSelfDllPath ).second;
			}
			printf("SWHH: DLL_PROCESS_ATTACH, pid:%u\n", (uint32_t)GetCurrentProcessId() );
			printf("      [%s] [%s]\n",
					Swhh2->srSelfExeBaseName.c_str(),
					Swhh2->srSelfDllBaseName.c_str() );
		}
		break;
	case DLL_PROCESS_DETACH:{
			if( Swhh2 ){
				if( Swhh2->hHook2 ){
					if( !UnhookWindowsHookEx( Swhh2->hHook2 ) ){
						printf("SWHH: ERROR: Unhook failed. Pid:%u [lOySRO]\n", (uint32_t)GetCurrentProcessId() );
					}
					Swhh2->hHook2 = 0;
				}
				delete Swhh2;
				Swhh2 = nullptr;
			}
		}
		break;
	}
	return 1;
}
uint32_t CALLBACK SwhhInit()
{
	assert( Swhh2 );
	printf("SWHH: SwhhInit()\n");
	printf("      [%s] [%s]\n",
			Swhh2->srSelfExeBaseName.c_str(),
			Swhh2->srSelfDllBaseName.c_str() );

	assert( !Swhh2->hHook2 );
	Swhh2->hHook2 = SetWindowsHookExA(
			WH_KEYBOARD_LL,
			SwhhLowLevelKeyboardProc,
			nullptr,   //NULL = current process.
			0 // 0 = all current desktop processes.
		);
	if( !Swhh2->hHook2 ){
		//MessageBox( 0, "SWHH: ERROR: SetWindowsHookExA(WH_KEYBOARD_LL,...) failed.", "ERROR", MB_OK|MB_ICONERROR );
		return 6003;
	}
	return 0; //0: success.
}
uint32_t CALLBACK SwhhDeinit()
{
	assert( Swhh2 );
	printf("SWHH: SwhhDeinit()\n");
	printf("      [%s] [%s]\n",
			Swhh2->srSelfExeBaseName.c_str(),
			Swhh2->srSelfDllBaseName.c_str() );
	if( !Swhh2->hHook2 ){
		return 6001;
	}
	if( !UnhookWindowsHookEx( Swhh2->hHook2 ) ){
		//printf("SWHH: ERROR: Unhook failed. Pid:%u []\n", (uint32_t)GetCurrentProcessId() );
		return 6002;
	}
	Swhh2->hHook2 = 0;
	return 0; //0: success.
}
/*	// By returning a non-zero value from the hook procedure, the
	// message does not get passed to the target window
	KBDLLHOOKSTRUCT* pkbhs = (KBDLLHOOKSTRUCT*)lParam;
	switch( nCode ){
		case HC_ACTION:{
			//bool bCtrlDown = !!( 0x8000 & GetAsyncKeyState( VK_CONTROL ) );
			bool bShiftDown = !!( 0x8000 & GetAsyncKeyState( VK_SHIFT ) );

			// Disable ALT+TAB
			if( pkbhs->vkCode == VK_TAB && pkbhs->flags & LLKHF_ALTDOWN && !bShiftDown ){
				printf("SWHH: ALT-TAB Pressed. Pid:%u\n", (uint32_t)GetCurrentProcessId() );
				return 1;
			}
			// Disable ALT+ESC
			if( pkbhs->vkCode == VK_ESCAPE && pkbhs->flags & LLKHF_ALTDOWN ){
				printf("SWHH: ALT-ESC Pressed. Pid:%u\n", (uint32_t)GetCurrentProcessId() );
				return 1;
			}
			break;
		}
	}
//*/
LRESULT CALLBACK SwhhLowLevelKeyboardProc( INT nCode, WPARAM wParam, LPARAM lParam )
{
	assert( Swhh2 );
	if( !Swhh2->hHook2 ){
		return 0;
	}
	assert( Swhh2->hHook2 );
	if( nCode < 0 || !Swhh2->calbSwh ){
		return CallNextHookEx( Swhh2->hHook2, nCode, wParam, lParam );
	}
	assert( Swhh2->calbSwh );
	size_t rs2 = Swhh2->calbSwh( nCode, wParam, lParam, Swhh2->user3 );
	if( rs2 == 2 ){
		return CallNextHookEx( Swhh2->hHook2, nCode, wParam, lParam );
	}
	return rs2;
}
uint32_t CALLBACK SwhhSetSWHCallback( SWHH_SwhCallback calb2, void* user2 )
{
	assert( Swhh2 );
	Swhh2->calbSwh = calb2;
	Swhh2->user3   = user2;
	return 0; //0: success.
}
