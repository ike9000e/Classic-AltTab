#pragma once
#include <windows.h>
#include <shellapi.h>   //NOTIFYICONDATA
#include <vector>
#include <string>
#include "hxdw_utils.h"
#include "hxdw_process.h"

struct AtzSWNeedle; struct AtzWCETInfos;

;    template<class Txx>
bool AtzAny( Txx needle2, std::vector<Txx> arr2 );
auto AtzStrToHKPair( const char* inp, const char* szVarname ) -> std::pair<int32_t,int32_t>;
bool AtzTestWindowForSWTabbing( const std::vector<AtzSWNeedle>& aWndListToOmit3, const AtzWCETInfos& );
bool AtzGetWindowClassInfos( HWND hwnd, AtzWCETInfos* outp );

using SWHH_SwhhInit = uint32_t(CALLBACK*)();//SwhhInit
using SWHH_SwhhDeinit = uint32_t(CALLBACK*)();//SwhhDeinit
using SWHH_SwhCallback = uint32_t(CALLBACK*)( INT nCode, WPARAM wParam, LPARAM lParam, void* user2 );
using SWHH_SwhhSetSWHCallback = uint32_t(CALLBACK*)( SWHH_SwhCallback calb2, void* user2 );

template<class Txx>
bool AtzAny( Txx needle2, std::vector<Txx> arr2 )
{
	auto a = std::find( arr2.begin(), arr2.end(), needle2 );
	return a != arr2.end();
}
struct AtzWCETInfos{
	std::string srClassName2;
	std::string srExecBaseName;
	std::string srWndTitle;
	uint64_t    pid4;
};
enum : uint32_t {
	ATZ_ESWF_EmptyNameIsMatch = 0x1,
};
struct AtzSWNeedle {
	std::string srClassName3;
	std::string srClassNeedle3;
	uint32_t    uCNFlags;
	std::string srExecName3;
	std::string srExecNeedle3;
	uint32_t    uENFlags;
	std::string srTitleName3;
	std::string srTitleNeedle3;
	uint32_t    uTNFlags;
	//
	bool isEmpty3()const;
};

/// Config for AtzMainWindow.
struct AtzAppDTO{
	bool          bStartVisible = 0L;
	bool          bTopmost = 1L;
	bool          bTrayIcon = 1L;
	bool          bPrintWndNames2 = 0L;
	bool          bShowExeName = 0L;
	int           nMaxTitleLen = 64;
	int           nWinListOmitMode = 10;   // Possible values: 10,7,0
	std::string   srLabelSeparator = "|";  //anLabelSeparator
	uint32_t      uClrWindow       = 0x00FF0000; //format: 0x00BBGGRR. "-color_spec"
	uint32_t      uClrTextNormal   = 0x00000000;
	uint32_t      uClrTextSelected = 0x00FFFFFF;
	uint32_t      uClrBgNormal     = 0x00FF4040;
	uint32_t      uClrBgSelected   = 0x00800040;
	bool          bUseSystemAltTab = 1L;
	int32_t       nToForeFixMs2 = 320;   //0: disable.
	std::pair<int32_t,int32_t> anHKAltTab = { 8, 192,}; // (1,9) (1,192) // 192 = tilde, aka. grave, aka. accent.
	std::pair<int32_t,int32_t> anHKAltShiftTab = { 8+4, 192,}; // (8+4,192)
	std::vector<AtzSWNeedle>   aWndListToOmit2;
};

/// Main window as a class that also shows a tray icon.
struct AtzMainWindow {
	;           AtzMainWindow( int, int, const AtzAppDTO& cmdtricn_ );
	;           ~AtzMainWindow();
	int         run2();
	uint32_t    AtzLowLevelKeyboardProc3( INT nCode, WPARAM wParam, LPARAM lParam );
	static const char* getAppName();
private:
	struct SWndDt;
	friend LRESULT CALLBACK WndProc2( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam );
	auto        WndProc3( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam ) -> LRESULT;
	ATOM        registerHlprWndClass( HINSTANCE hInstance );
	bool        initInstance( HINSTANCE hInstance, int nCmdShow );
	void        initializeTrayIcon();
	bool        initHelperDll();
	void        toggleOwnWindowVisibility( int bShow2 );
	void        onOwnModkeyUp();
	void        onScrollHotkeyAction( int idHotkey );
	bool        getLiveWindowListForTabbing( std::vector<SWndDt>* outp );
	bool        showMessage2( const char* szMsg, const char* flags2, size_t );
private:
	enum : int{
		mWMTrayAnyMessageId = WM_USER+4136, //WM_USER=1024
		mWMDestroyLv2Id,  //=WM_USER+4137
		mActIdTabPrev = 3001,
		mActIdTabNext = 3002,
		mTFTmr_Inactive = 0,
		mTFTmr_FromSysKey = 1,
		mTimerIdToFore      = 3003,
		mTimerIdToForeFix2  = 3004,
		mMaxTFTmrRetry      = 8,
		mMaxTFTmrDurationMs = 500,
	};
	struct SWndDt{
		std::string  title2;
		std::string  name2;
		std::string  classname2;
		HWND         hwnd2 = 0;
		HICON        hWndIcon = 0;
		uint64_t     pid3;
	};
	// Timer infos used to check if the main window has been activated;
	// and if not, retry with activating it; configured number of times.
	struct SToForeTmr{
		int      eAtStep = mTFTmr_Inactive;
		uint32_t uCntRetry = 0, uStartedAt = 0;
	};
	AtzAppDTO             mAppDTO;
	HWND                  mHwnd = 0, mTabbingWnd = 0;
	NOTIFYICONDATA        mNid;
	bool                  mIsInTray = 0L;
	int                   mTabbingPos = 0;
	HBRUSH                mHBrWindow = 0, mHBrBgNormal = 0, mHBrBgSelected = 0;
	std::vector<int32_t>  mAModkeyUsing;
	HMODULE               mHDll2 = 0;
	std::string           mHelperDllName2 = "swh_helper_dll.dll";
	DWORD                 mDwMainThreadId = 0;
	SToForeTmr            mTFTmr;
	SToForeTmr            mTFTmrFix2;
};
