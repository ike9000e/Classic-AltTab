#pragma once
// To silence some macro redefinition warnings with MSVC2017.
// ref: https://stackoverflow.com/questions/14363929/vs2012-c-warning-c4005-useheader-macro-redefinition
#define _USING_V110_SDK71_ 1
#include <string>
#include <vector>
#include <inttypes.h>
#include <algorithm>
#include <functional>
#include <windows.h>
#include <assert.h>

using SWHH_SwhCallback = uint32_t(CALLBACK*)( INT nCode, WPARAM wParam, LPARAM lParam, void* user2 );

uint32_t CALLBACK SwhhInit();
uint32_t CALLBACK SwhhDeinit();
uint32_t CALLBACK SwhhSetSWHCallback( SWHH_SwhCallback calb2, void* user2 );

LRESULT CALLBACK SwhhLowLevelKeyboardProc( INT nCode, WPARAM wParam, LPARAM lParam );
struct SwhhData2 {
	std::string      srSelfDllPath;
	std::string      srSelfDllBaseName;
	std::string      srSelfExePath;
	std::string      srSelfExeBaseName;
	HHOOK            hHook2 = 0;
	SWHH_SwhCallback calbSwh = nullptr;
	void*            user3 = nullptr;
};
extern SwhhData2* Swhh2;


